import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import clearanceSale from "@/assets/hero-clearance-sale.png";
import resinArt from "@/assets/hero-resin-art.png";
import schoolSupplies from "@/assets/hero-school-supplies.png";
import goldJewellery from "@/assets/hero-gold-plated-jewellery.webp";

const slides = [
  {
    label: "Clearance Sale",
    href: "/shop/clearance-sale",
    img: clearanceSale,
    alt: "Clearance sale banner with big sale offer artwork",
    buttonClass: "bg-[#111111] text-white hover:bg-[#E53935]",
    mobileBg: "bg-[#D1AE18]",
  },
  {
    label: "Resin Art",
    href: "/shop/resin-art",
    img: resinArt,
    alt: "Artistic crafts banner with handmade decor",
    buttonClass: "bg-[#111111] text-white hover:bg-[#C1602B]",
    mobileBg: "bg-white",
  },
  {
    label: "School Essentials",
    href: "/shop/school-essentials",
    img: schoolSupplies,
    alt: "School supplies banner with stationery and pencil pouch",
    buttonClass: "bg-[#0077CC] text-white hover:bg-[#005FA3]",
    mobileBg: "bg-[#91DCE5]",
  },
  {
    label: "Gold-Plated Jewellery",
    href: "/shop/gold-plated-jewellery",
    img: goldJewellery,
    alt: "Gold-plated jewellery banner with model wearing jewellery",
    buttonClass: "bg-[#C9A84C] text-black hover:bg-[#F5E6C8]",
    mobileBg: "bg-[#B1A58D]",
  },
];

const Hero = () => {
  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveSlide((current) => (current + 1) % slides.length);
    }, 2500);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="w-full overflow-hidden bg-background" aria-label="Featured collections">
      <div className="relative h-[230px] overflow-hidden sm:h-[340px] md:h-[460px] lg:h-[520px]">
        <div
          className="flex h-full transition-transform duration-700 ease-out"
          style={{ transform: `translateX(-${activeSlide * 100}%)` }}
        >
          {slides.map((slide) => (
            <article key={slide.href} className={`relative h-full w-full shrink-0 overflow-hidden ${slide.mobileBg}`}>
              <img
                src={slide.img}
                alt={slide.alt}
                className="h-full w-full object-contain md:object-cover"
                width={1713}
                height={624}
                loading={slide.href === slides[0].href ? "eager" : "lazy"}
              />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 px-4 py-4 sm:px-8 sm:py-6 md:px-12">
                <Link
                  to={slide.href}
                  aria-label={`Shop ${slide.label}`}
                  className={`inline-flex min-h-10 items-center justify-center rounded-sm px-5 text-[11px] font-bold uppercase tracking-[0.14em] shadow-[0_12px_28px_rgba(0,0,0,0.18)] transition-colors sm:min-h-11 sm:px-7 sm:text-[12px] sm:tracking-[0.18em] ${slide.buttonClass}`}
                >
                  Shop Now
                </Link>
              </div>
            </article>
          ))}
        </div>

        <div className="absolute bottom-4 right-4 flex gap-2 sm:bottom-5 sm:right-5" aria-label="Carousel slide indicators">
          {slides.map((slide, index) => (
            <button
              key={slide.href}
              type="button"
              aria-label={`Show ${slide.label}`}
              aria-current={activeSlide === index}
              onClick={() => setActiveSlide(index)}
              className={`h-2.5 rounded-full transition-all ${
                activeSlide === index ? "w-8 bg-white" : "w-2.5 bg-white/55 hover:bg-white"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
